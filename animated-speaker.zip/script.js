function speakNow() {
  const text = document.getElementById('text').value;
  const lang = document.getElementById('language').value;
  const emotion = document.getElementById('emotion').value;
  const character = document.getElementById('character');

  if (!text) return alert("Type something to speak!");

  // Reset classes
  character.className = 'character';

  // Add emotion + fake mouth animation
  if (emotion !== 'normal') character.classList.add(emotion);
  character.classList.add('mouth-move');

  const msg = new SpeechSynthesisUtterance(text);
  msg.lang = lang;
  msg.pitch = 1;
  msg.rate = 0.9;

  msg.onend = () => {
    character.className = 'character'; // Reset after speaking
  };

  window.speechSynthesis.speak(msg);
}
